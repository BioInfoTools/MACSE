#!/usr/bin/python

def read_FASTA_strings(filename):
	with open(filename) as file:
		return file.read().split('>')[1:]

def read_FASTA_sequences(filename):
	return map(lambda seq: ''.join(seq.split('\n')[1:]), read_FASTA_strings(filename))

import os
import time;

config_data= []
with open("config.txt") as file:
	config_data = file.read().split('\n')

if not os.path.exists(config_data[6]): os.mkdir(config_data[6])
for file_name in os.listdir("./" + config_data[5]):
	os.system("./multy "+ ''.join(map(lambda seq: seq + ' ', read_FASTA_sequences("./" + config_data[5] + "/" + file_name))[0:2]) + ''.join(map(lambda seq: seq + ' ', config_data[0:5])) + "> results.txt")
	os.rename("results.txt", config_data[6] + "/" + file_name + "_" + time.asctime(time.localtime(time.time())))  


